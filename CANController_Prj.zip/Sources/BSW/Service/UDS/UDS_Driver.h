/*
 * UDS_Driver.h
 *
 *  Created on: 2018-10-13
 *      Author: dalad
 */
/************************************************************************
Copyright (c) ECO-EV Technologies Co., Ltd. All rights reserved.

File name:     Ser_Task.h
Author:        ECO-EV
Version:
Date:
Description:
Others:
History:

   1. Date:
      Author:
      Modification:
   2. ...
*************************************************************************/
#ifndef   _UDS_DRIVER_H_
#define   _UDS_DRIVER_H_

#include "MCAL_CAN.h"

/******************************************************************************
Exported Function Declarations
******************************************************************************/
extern void UDS_EntryOnlineProgram(Mcal_CAN_Node CANNode);



#endif


